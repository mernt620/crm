import DashboardModule from '@/modules/DashboardModule';
export default function Dashboard() {
  return <DashboardModule />;
}
